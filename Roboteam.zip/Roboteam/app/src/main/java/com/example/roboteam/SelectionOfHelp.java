package com.example.roboteam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.robotemi.sdk.Robot;
import com.robotemi.sdk.TtsRequest;

public class SelectionOfHelp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selection_of_help);
    }

    public void helpYes(View view) {
        Intent intent = new Intent(this, PersonSelection.class);
        startActivity(intent);
    }

    public void helpNo(View view) {
        Robot.getInstance().speak(TtsRequest.create("Thank you, have a good day! Let me know if you need any future help", true));

    }
}
