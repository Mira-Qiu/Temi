package com.example.roboteam;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.robotemi.sdk.Robot;
import com.robotemi.sdk.TtsRequest;

public class StylistSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stylist_selection);
    }


    public void callStylist(View view) {
        String peerId = Robot.getInstance().getAdminInfo().getUserId();
        String name = Robot.getInstance().getAdminInfo().getName();
        Robot.getInstance().startTelepresence(name,peerId);
    }

    public void speak(View view) {
        Robot.getInstance().speak(TtsRequest.create("Here I would generally give you a tour of FootLocker", true));
    }
}

